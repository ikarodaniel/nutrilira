variaveis,
loop for,
condicionais com if, 
operações matematicas, 
console.log
criação de listas,
funções